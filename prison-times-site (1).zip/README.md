# Prison Times — journal Roblox Prison RP

Application web en français : journal public, connexion privée, rédaction, recrutement et panel staff avec rôles.

## Fonctions incluses

- Journal public et articles publiés.
- Comptes créés via Supabase Auth (les nouveaux comptes ont le rôle `journalist`).
- Rédaction d'articles et envoi en validation.
- Validation/refus des articles par Owner et Gérant.
- Candidatures de recrutement et décision du Owner/Gérant.
- Gestion des rôles réservée à l'Owner.
- Interface sombre responsive, adaptée mobile.
- Politiques Row Level Security (RLS) dans `supabase/schema.sql`.

## Prérequis

- Node.js 20 ou plus récent
- Un compte Supabase (offre gratuite possible)

## Installation

1. Crée un projet sur https://supabase.com/
2. Ouvre **SQL Editor**, colle le contenu de `supabase/schema.sql`, puis exécute-le.
3. Copie `.env.example` vers `.env` à la racine.
4. Dans Supabase > Project Settings > API, copie :
   - Project URL vers `VITE_SUPABASE_URL`
   - la clé publique `anon` (ou publishable key compatible) vers `VITE_SUPABASE_ANON_KEY`
5. Dans un terminal à la racine du projet :

   ```bash
   npm install
   npm run dev
   ```

6. Ouvre l'adresse locale affichée par Vite, généralement `http://localhost:5173`.

## Créer le compte Owner

1. Crée ton compte via le bouton **Connexion** puis **Créer un compte**.
2. Dans Supabase > Authentication > Users, copie l'UUID de ton compte.
3. Dans Supabase > SQL Editor, exécute cette commande en remplaçant l'UUID :

   ```sql
   update public.profiles
   set role = 'owner'
   where id = 'TON-UUID-ICI';
   ```

4. Déconnecte-toi puis reconnecte-toi au site.

Ne laisse jamais le rôle Owner attribuable librement par l'inscription. Le rôle initial est Journaliste et seul l'Owner peut changer les rôles depuis le panel.

## Rôles

- **Owner** : accès total, gestion des rôles, validation et publications.
- **Gérant des journalistes** : examine les candidatures et valide les articles.
- **Administrateur** : consulte l'équipe et les candidatures; ne peut pas changer les rôles ni valider les articles.
- **Journaliste** : rédige et soumet des articles.

## Déploiement en ligne

Tu peux déployer le projet sur un hébergeur compatible Vite (par exemple Vercel ou Netlify). Ajoute les deux variables d'environnement `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` dans les paramètres du projet hébergé, puis lance le build `npm run build`.

## Sécurité et limites de cette première version

- Les accès aux données sont protégés par RLS dans Supabase. N'ajoute jamais la clé `service_role` à un fichier `VITE_*` ni au code du navigateur.
- Le champ image accepte une URL d'image publique; aucun système d'upload de fichier n'est configuré.
- L'acceptation d'une candidature met à jour son statut, mais n'attribue pas automatiquement le rôle Journaliste. L'Owner peut gérer les rôles depuis le panel.
- L'administrateur est limité à la consultation du staff/candidatures dans cette version; les outils de modération avancée peuvent être ajoutés ensuite.
- Pour un site public en production, configure la confirmation d'e-mail et une politique anti-spam/rate-limit pour les candidatures.
