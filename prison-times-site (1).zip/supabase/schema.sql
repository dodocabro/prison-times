-- PRISON TIMES — schéma Supabase
-- Exécuter ce fichier dans Supabase > SQL Editor.
-- La clé service_role ne doit JAMAIS être utilisée dans le navigateur.

create extension if not exists pgcrypto;

create type public.site_role as enum ('owner', 'manager', 'admin', 'journalist');
create type public.article_status as enum ('draft', 'pending', 'published', 'rejected');
create type public.application_status as enum ('pending', 'accepted', 'rejected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text not null default 'Journaliste',
  roblox_username text,
  role public.site_role not null default 'journalist',
  created_at timestamptz not null default now()
);

create table public.articles (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 3 and 120),
  category text not null default 'Actualités',
  excerpt text not null check (char_length(excerpt) <= 220),
  content text not null,
  image_url text,
  author_id uuid not null references public.profiles(id) on delete restrict,
  author_name text not null default 'Rédaction',
  status public.article_status not null default 'pending',
  created_at timestamptz not null default now(),
  published_at timestamptz
);

create table public.applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  display_name text not null,
  roblox_username text not null,
  motivation text not null,
  status public.application_status not null default 'pending',
  reviewed_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  target_type text not null,
  target_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index articles_status_published_idx on public.articles(status, published_at desc);
create index applications_status_idx on public.applications(status, created_at desc);

-- Create a profile for each new authenticated user. All new accounts start as journalists.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, display_name)
  values (
    new.id,
    new.email,
    coalesce(nullif(new.raw_user_meta_data ->> 'display_name', ''), 'Journaliste')
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Helper functions are security definer to avoid recursive RLS checks.
create or replace function public.current_site_role()
returns public.site_role
language sql stable security definer
set search_path = ''
as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.is_staff()
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select coalesce(public.current_site_role() in ('owner', 'manager', 'admin'), false)
$$;

alter table public.profiles enable row level security;
alter table public.articles enable row level security;
alter table public.applications enable row level security;
alter table public.audit_logs enable row level security;

grant usage on schema public to anon, authenticated;
grant select on public.articles to anon, authenticated;
grant insert, update, delete on public.articles to authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select, insert, update on public.applications to anon, authenticated;
grant select, insert on public.audit_logs to authenticated;

-- Profiles: members can read their own profile; staff can read team records.
create policy "profile read self or staff" on public.profiles
for select to authenticated
using (id = auth.uid() or public.is_staff());

create policy "profile update owner only" on public.profiles
for update to authenticated
using (public.current_site_role() = 'owner')
with check (public.current_site_role() = 'owner');

-- Profiles are created by the trigger, not directly by users.
create policy "published articles are public" on public.articles
for select to anon, authenticated
using (status = 'published' or author_id = auth.uid() or public.current_site_role() in ('owner', 'manager', 'admin'));

create policy "journalists submit own articles" on public.articles
for insert to authenticated
with check (
  author_id = auth.uid()
  and public.current_site_role() in ('owner', 'manager', 'journalist')
  and status in ('draft', 'pending', 'published')
  and (status <> 'published' or public.current_site_role() = 'owner')
);

create policy "owner or manager reviews articles" on public.articles
for update to authenticated
using (
  public.current_site_role() in ('owner', 'manager')
  or (author_id = auth.uid() and status in ('draft', 'rejected'))
)
with check (
  public.current_site_role() in ('owner', 'manager')
  or (author_id = auth.uid() and status in ('draft', 'pending', 'rejected'))
);

create policy "owner can delete articles" on public.articles
for delete to authenticated
using (public.current_site_role() = 'owner');

-- Public recruitment form; staff can read and review applications.
create policy "anyone can submit application" on public.applications
for insert to anon, authenticated
with check (status = 'pending');

create policy "staff can read applications" on public.applications
for select to authenticated
using (public.current_site_role() in ('owner', 'manager', 'admin'));

create policy "owner or manager reviews applications" on public.applications
for update to authenticated
using (public.current_site_role() in ('owner', 'manager'))
with check (public.current_site_role() in ('owner', 'manager'));

create policy "staff can read audit logs" on public.audit_logs
for select to authenticated
using (public.current_site_role() in ('owner', 'admin'));

create policy "staff can add audit logs" on public.audit_logs
for insert to authenticated
with check (actor_id = auth.uid() and public.current_site_role() in ('owner', 'manager', 'admin'));

-- IMPORTANT: after creating your account, promote it to Owner manually.
-- Find your user UUID in Authentication > Users, then run:
-- update public.profiles set role = 'owner' where id = 'YOUR-USER-UUID';
