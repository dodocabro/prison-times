import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import { Newspaper, Shield, Crown, Users, PenLine, LogIn, LogOut, Plus, Check, X, Clock, Search, Menu, Send, FileText, UserCog, Megaphone, Eye, Trash2, RefreshCw } from 'lucide-react';
import './style.css';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

const ROLE_LABELS = {
  owner: 'Owner',
  manager: 'Gérant des journalistes',
  admin: 'Administrateur',
  journalist: 'Journaliste'
};
const ROLE_HELP = {
  owner: 'Accès complet : équipe, rôles, articles et paramètres.',
  manager: 'Gère les journalistes, les candidatures et valide les articles.',
  admin: 'Modération et gestion opérationnelle du staff, sans pouvoir attribuer les rôles élevés.',
  journalist: 'Rédige des articles et les soumet au gérant.'
};
const categories = ['Actualités', 'Faits divers', 'Police', 'Annonces', 'Rapports'];

function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [articles, setArticles] = useState([]);
  const [profiles, setProfiles] = useState([]);
  const [applications, setApplications] = useState([]);
  const [tab, setTab] = useState('home');
  const [authMode, setAuthMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [authMessage, setAuthMessage] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [articleForm, setArticleForm] = useState({ title: '', category: 'Actualités', excerpt: '', content: '', image_url: '' });
  const [applicationForm, setApplicationForm] = useState({ display_name: '', roblox_username: '', motivation: '' });
  const [mobileNav, setMobileNav] = useState(false);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => setSession(newSession));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (session?.user) loadProfile();
    else { setProfile(null); setProfiles([]); setApplications([]); }
  }, [session]);

  useEffect(() => { loadArticles(); }, [profile]);

  async function loadProfile() {
    const { data, error } = await supabase.from('profiles').select('*').eq('id', session.user.id).maybeSingle();
    if (error) setMessage(error.message);
    setProfile(data || null);
  }
  async function loadArticles() {
    if (!supabase) return;
    const { data, error } = await supabase.from('articles').select('*').eq('status', 'published').order('published_at', { ascending: false });
    if (error) console.error(error);
    setArticles(data || []);
  }
  async function loadPanelData() {
    if (!profile || !['owner', 'manager', 'admin'].includes(profile.role)) return;
    const [p, a] = await Promise.all([
      supabase.from('profiles').select('id, display_name, email, roblox_username, role, created_at').order('created_at', { ascending: false }),
      supabase.from('applications').select('*').order('created_at', { ascending: false })
    ]);
    if (p.error) setMessage(p.error.message); else setProfiles(p.data || []);
    if (a.error) setMessage(a.error.message); else setApplications(a.data || []);
  }
  useEffect(() => { if (profile) loadPanelData(); }, [profile, tab]);

  const isStaff = ['owner', 'manager', 'admin'].includes(profile?.role);
  const canManageRoles = profile?.role === 'owner';
  const canReview = ['owner', 'manager'].includes(profile?.role);
  const canWrite = ['owner', 'manager', 'journalist'].includes(profile?.role);
  const visibleArticles = useMemo(() => articles.filter(a => `${a.title} ${a.excerpt} ${a.category}`.toLowerCase().includes(search.toLowerCase())), [articles, search]);

  async function signIn(e) {
    e.preventDefault(); setLoading(true); setAuthMessage('');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setAuthMessage(error ? error.message : 'Connexion réussie.');
    setLoading(false);
  }
  async function signUp(e) {
    e.preventDefault(); setLoading(true); setAuthMessage('');
    const { error } = await supabase.auth.signUp({ email, password, options: { data: { display_name: displayName } } });
    setAuthMessage(error ? error.message : 'Compte créé. Vérifie ton e-mail si la confirmation est activée. Le rôle initial est Journaliste.');
    setLoading(false);
  }
  async function signOut() { await supabase.auth.signOut(); setTab('home'); setMessage(''); }
  async function submitArticle(e) {
    e.preventDefault();
    const { error } = await supabase.from('articles').insert({
      ...articleForm, author_id: session.user.id, author_name: profile.display_name || profile.email,
      status: profile.role === 'owner' ? 'published' : 'pending',
      published_at: profile.role === 'owner' ? new Date().toISOString() : null
    });
    if (error) setMessage(error.message);
    else { setMessage(profile.role === 'owner' ? 'Article publié.' : 'Article envoyé au gérant pour validation.'); setArticleForm({ title: '', category: 'Actualités', excerpt: '', content: '', image_url: '' }); setTab('home'); await loadArticles(); }
  }
  async function reviewArticle(id, status) {
    const { error } = await supabase.from('articles').update({ status, published_at: status === 'published' ? new Date().toISOString() : null }).eq('id', id);
    setMessage(error ? error.message : (status === 'published' ? 'Article publié.' : 'Article refusé.'));
    await loadPanelData(); await loadArticles();
  }
  async function changeRole(id, role) {
    if (!canManageRoles) return;
    const { error } = await supabase.from('profiles').update({ role }).eq('id', id);
    setMessage(error ? error.message : 'Rôle mis à jour.');
    await loadPanelData();
  }
  async function submitApplication(e) {
    e.preventDefault();
    const { error } = await supabase.from('applications').insert({ ...applicationForm, user_id: session?.user?.id || null, status: 'pending' });
    setMessage(error ? error.message : 'Candidature envoyée !');
    if (!error) setApplicationForm({ display_name: '', roblox_username: '', motivation: '' });
  }
  async function reviewApplication(id, status) {
    const { error } = await supabase.from('applications').update({ status, reviewed_by: session.user.id }).eq('id', id);
    setMessage(error ? error.message : 'Candidature mise à jour.');
    await loadPanelData();
  }

  if (!supabase) return <SetupScreen />;
  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="icon-button mobile-menu" onClick={() => setMobileNav(!mobileNav)} aria-label="Ouvrir le menu"><Menu size={20}/></button>
        <button className="brand" onClick={() => setTab('home')}>
          <span className="brand-mark"><Newspaper size={22}/></span>
          <span><strong>PRISON TIMES</strong><small>OFFICIAL PRISON ROLEPLAY NEWS</small></span>
        </button>
        <nav className={mobileNav ? 'main-nav open' : 'main-nav'}>
          <button className={tab === 'home' ? 'nav-link active' : 'nav-link'} onClick={() => { setTab('home'); setMobileNav(false); }}>Journal</button>
          <button className={tab === 'apply' ? 'nav-link active' : 'nav-link'} onClick={() => { setTab('apply'); setMobileNav(false); }}>Recrutement</button>
          {session && <button className={tab === 'write' ? 'nav-link active' : 'nav-link'} onClick={() => { setTab('write'); setMobileNav(false); }}>Rédiger</button>}
          {isStaff && <button className={tab === 'panel' ? 'nav-link active' : 'nav-link'} onClick={() => { setTab('panel'); setMobileNav(false); }}>Panel staff</button>}
        </nav>
        <div className="top-actions">
          {session ? <><span className="user-chip"><span className="online-dot"/>{profile?.display_name || session.user.email}</span><button className="icon-button" onClick={signOut} title="Déconnexion"><LogOut size={18}/></button></> : <button className="button button-primary button-small" onClick={() => setTab('login')}><LogIn size={16}/> Connexion</button>}
        </div>
      </header>

      <main>
        {message && <div className="notice"><span>{message}</span><button onClick={() => setMessage('')}><X size={16}/></button></div>}
        {tab === 'login' && <section className="auth-layout">
          <div className="auth-art"><div className="eyebrow"><Shield size={15}/> ACCÈS RÉSERVÉ</div><h1>La rédaction<br/><em>vous attend.</em></h1><p>Connecte-toi à ton espace pour rédiger et gérer les actualités de Prison Times.</p></div>
          <form className="form-card" onSubmit={authMode === 'login' ? signIn : signUp}>
            <h2>{authMode === 'login' ? 'Connexion au panel' : 'Créer un compte'}</h2><p className="muted">Les nouveaux comptes reçoivent le rôle Journaliste par défaut.</p>
            {authMode === 'signup' && <label>Nom affiché<input required value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="Nom de journaliste"/></label>}
            <label>E-mail<input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="nom@exemple.com"/></label>
            <label>Mot de passe<input required minLength={8} type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="8 caractères minimum"/></label>
            <button className="button button-primary full" disabled={loading}>{loading ? 'Chargement…' : authMode === 'login' ? 'Se connecter' : 'Créer mon compte'}</button>
            <p className="form-foot">{authMode === 'login' ? 'Pas encore de compte ?' : 'Déjà inscrit ?'} <button type="button" className="text-button" onClick={() => { setAuthMode(authMode === 'login' ? 'signup' : 'login'); setAuthMessage(''); }}>{authMode === 'login' ? 'Créer un compte' : 'Se connecter'}</button></p>
            {authMessage && <p className="inline-message">{authMessage}</p>}
          </form>
        </section>}

        {tab === 'home' && <>
          <section className="hero">
            <div className="hero-copy"><div className="eyebrow"><span className="live-dot"/> LE JOURNAL DE VOTRE SERVEUR</div><h1>L'information<br/>derrière <em>les barreaux.</em></h1><p>Les actualités, les interventions et les annonces officielles de la communauté Prison RP.</p><div className="hero-actions"><button className="button button-primary" onClick={() => document.getElementById('latest')?.scrollIntoView({ behavior: 'smooth' })}>Lire les actualités <Eye size={17}/></button><button className="button button-ghost" onClick={() => setTab('apply')}>Rejoindre la rédaction <Users size={17}/></button></div></div>
            <div className="hero-visual"><div className="hero-stamp"><Shield size={26}/><span>OFFICIAL<br/>NEWS DESK</span></div><div className="hero-number">PT<span> / 01</span></div><div className="hero-caption">PRISON TIMES <span>•</span> EST. 2025</div></div>
          </section>
          <section className="ticker"><span className="ticker-label"><Megaphone size={15}/> À LA UNE</span><span>Le journal officiel de votre serveur Prison RP</span><span className="ticker-date">{new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })}</span></section>
          <section id="latest" className="section-block"><div className="section-heading"><div><div className="eyebrow">LA RÉDACTION</div><h2>Dernières <em>publications</em></h2></div><label className="search-box"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher un article…"/></label></div>
            {visibleArticles.length ? <div className="article-grid">{visibleArticles.map(a => <ArticleCard key={a.id} article={a}/>)}</div> : <div className="empty-state"><span className="empty-icon"><Newspaper size={25}/></span><h3>Aucun article pour le moment</h3><p>Les publications validées par la rédaction apparaîtront ici.</p>{session && canWrite && <button className="button button-primary" onClick={() => setTab('write')}><Plus size={16}/> Rédiger le premier article</button>}</div>}
          </section>
        </>}

        {tab === 'apply' && <section className="content-page narrow"><div className="eyebrow">REJOINS LA RÉDACTION</div><h1>Ta plume peut<br/><em>faire la différence.</em></h1><p className="muted lead">Tu souhaites couvrir les événements, les interventions ou les annonces de ton serveur ? Envoie ta candidature à l'équipe Prison Times.</p><form className="form-card wide" onSubmit={submitApplication}><label>Nom affiché<input required value={applicationForm.display_name} onChange={e => setApplicationForm({...applicationForm, display_name:e.target.value})} placeholder="Ton nom"/></label><label>Nom d'utilisateur Roblox<input required value={applicationForm.roblox_username} onChange={e => setApplicationForm({...applicationForm, roblox_username:e.target.value})} placeholder="Pseudo Roblox"/></label><label>Pourquoi veux-tu rejoindre le journal ?<textarea required rows="5" value={applicationForm.motivation} onChange={e => setApplicationForm({...applicationForm, motivation:e.target.value})} placeholder="Présente-toi et explique tes motivations…"/></label><button className="button button-primary full"><Send size={16}/> Envoyer ma candidature</button><p className="muted tiny">Les candidatures sont examinées par le gérant des journalistes.</p></form></section>}

        {tab === 'write' && <section className="content-page narrow"><div className="eyebrow">ESPACE RÉDACTION</div><h1>Nouvel <em>article.</em></h1>{!session ? <LoginPrompt onClick={() => setTab('login')}/> : !canWrite ? <div className="empty-state"><h3>Accès réservé à la rédaction</h3><p>Ton compte n'a pas encore le rôle nécessaire.</p></div> : <form className="form-card wide" onSubmit={submitArticle}><label>Titre de l'article<input required maxLength="120" value={articleForm.title} onChange={e => setArticleForm({...articleForm,title:e.target.value})} placeholder="Un titre clair et accrocheur"/></label><label>Rubrique<select value={articleForm.category} onChange={e => setArticleForm({...articleForm,category:e.target.value})}>{categories.map(c => <option key={c}>{c}</option>)}</select></label><label>Résumé<input required maxLength="220" value={articleForm.excerpt} onChange={e => setArticleForm({...articleForm,excerpt:e.target.value})} placeholder="Un court résumé pour la page d'accueil"/></label><label>URL de l'image (facultatif)<input type="url" value={articleForm.image_url} onChange={e => setArticleForm({...articleForm,image_url:e.target.value})} placeholder="https://…"/></label><label>Contenu<textarea required rows="10" value={articleForm.content} onChange={e => setArticleForm({...articleForm,content:e.target.value})} placeholder="Rédige ton article ici…"/></label><button className="button button-primary full"><Send size={16}/>{profile?.role === 'owner' ? 'Publier l’article' : 'Envoyer pour validation'}</button></form>}</section>}

        {tab === 'panel' && <section className="content-page panel-page"><div className="panel-welcome"><div><div className="eyebrow">ESPACE SÉCURISÉ</div><h1>Panel <em>de gestion.</em></h1><p className="muted">Bienvenue, {profile?.display_name || session?.user?.email}.</p></div><div className="role-pill"><Shield size={15}/>{ROLE_LABELS[profile?.role] || 'Membre'}</div></div>
          {!isStaff ? <div className="empty-state"><h3>Accès refusé</h3><p>Ce panel est réservé au staff autorisé.</p></div> : <>
            <div className="stats-grid"><Stat icon={<Users/>} value={profiles.length} label="Membres"/><Stat icon={<FileText/>} value={articles.length} label="Articles publiés"/><Stat icon={<Clock/>} value={applications.filter(a => a.status === 'pending').length} label="Candidatures en attente"/><Stat icon={<PenLine/>} value="—" label="À valider"/></div>
            <div className="panel-grid">
              <section className="panel-card"><div className="panel-card-head"><div><h2>Équipe du journal</h2><p className="muted">Membres et permissions</p></div><button className="icon-button" onClick={loadPanelData} title="Actualiser"><RefreshCw size={17}/></button></div>
                <div className="table-wrap"><table><thead><tr><th>Membre</th><th>Rôle</th>{canManageRoles && <th>Modifier</th>}</tr></thead><tbody>{profiles.map(p => <tr key={p.id}><td><strong>{p.display_name || 'Membre'}</strong><small>{p.email || p.roblox_username || 'Compte membre'}</small></td><td><span className={`role-tag ${p.role}`}>{ROLE_LABELS[p.role] || p.role}</span></td>{canManageRoles && <td><select value={p.role} disabled={p.id === session.user.id} onChange={e => changeRole(p.id,e.target.value)} aria-label={`Rôle de ${p.display_name}`}><option value="journalist">Journaliste</option><option value="manager">Gérant</option><option value="admin">Administrateur</option><option value="owner">Owner</option></select></td>}</tr>)}</tbody></table></div>
                {!canManageRoles && <p className="muted tiny">Seul l'Owner peut attribuer ou modifier les rôles.</p>}
              </section>
              <section className="panel-card"><div className="panel-card-head"><div><h2>Candidatures</h2><p className="muted">Recrutement des journalistes</p></div><Users size={19}/></div>
                {applications.length ? <div className="stack-list">{applications.map(a => <div className="application-item" key={a.id}><div className="application-top"><strong>{a.display_name}</strong><span className={`status-tag ${a.status}`}>{a.status === 'pending' ? 'En attente' : a.status === 'accepted' ? 'Acceptée' : 'Refusée'}</span></div><small>Roblox : {a.roblox_username}</small><p>{a.motivation}</p>{canReview && a.status === 'pending' && <div className="button-row"><button className="button button-success button-small" onClick={() => reviewApplication(a.id,'accepted')}><Check size={15}/> Accepter</button><button className="button button-danger button-small" onClick={() => reviewApplication(a.id,'rejected')}><X size={15}/> Refuser</button></div>}</div>)}</div> : <p className="muted empty-inline">Aucune candidature pour le moment.</p>}
              </section>
            </div>
            {canReview && <section className="panel-card review-section"><div className="panel-card-head"><div><h2>Articles à valider</h2><p className="muted">Les journalistes attendent la décision du gérant.</p></div><Clock size={19}/></div><PendingArticles supabase={supabase} onReview={reviewArticle} canReview={canReview}/></section>}
            {profile?.role === 'admin' && <p className="notice info">Le rôle Administrateur peut consulter le staff et les candidatures, mais ne peut pas attribuer les rôles ni valider les articles.</p>}
          </>}
        </section>}
      </main>
      <footer><div className="footer-brand"><Newspaper size={19}/><strong>PRISON TIMES</strong></div><span>Un journal communautaire pour votre univers Prison RP.</span><span>© {new Date().getFullYear()} Prison Times</span></footer>
    </div>
  );
}

function ArticleCard({ article }) {
  return <article className="article-card"><div className="article-image" style={article.image_url ? { backgroundImage: `linear-gradient(180deg, transparent, rgba(5,10,20,.7)), url("${article.image_url}")` } : {}}><span className="category-label">{article.category}</span><span className="article-code">PT / NEWS</span></div><div className="article-body"><div className="article-meta">{article.author_name || 'Rédaction'} <span>•</span> {article.published_at ? new Date(article.published_at).toLocaleDateString('fr-FR') : ''}</div><h3>{article.title}</h3><p>{article.excerpt}</p><details><summary>Lire l'article <span>↗</span></summary><div className="full-article">{article.content}</div></details></div></article>;
}
function Stat({ icon, value, label }) { return <div className="stat-card"><span className="stat-icon">{icon}</span><strong>{value}</strong><span>{label}</span></div>; }
function LoginPrompt({ onClick }) { return <div className="empty-state"><h3>Connecte-toi pour rédiger</h3><p>Un compte journaliste est nécessaire pour soumettre un article.</p><button className="button button-primary" onClick={onClick}><LogIn size={16}/> Connexion</button></div>; }
function PendingArticles({ supabase, onReview, canReview }) {
  const [pending, setPending] = useState([]);
  const [err, setErr] = useState('');
  async function load() {
    const { data, error } = await supabase.from('articles').select('*').eq('status','pending').order('created_at',{ascending:false});
    if (error) setErr(error.message); else { setPending(data || []); setErr(''); }
  }
  useEffect(() => { load(); }, []);
  if (err) return <p className="muted">{err}</p>;
  if (!pending.length) return <p className="muted empty-inline">Aucun article en attente.</p>;
  return <div className="pending-list">{pending.map(a => <div className="pending-item" key={a.id}><div className="pending-copy"><span className="category-label">{a.category}</span><h3>{a.title}</h3><p>{a.excerpt}</p><small>Par {a.author_name || 'Journaliste'}</small><details><summary>Aperçu de l'article</summary><p>{a.content}</p></details></div>{canReview && <div className="button-row vertical"><button className="button button-success button-small" onClick={async()=>{await onReview(a.id,'published'); await load();}}><Check size={15}/> Publier</button><button className="button button-danger button-small" onClick={async()=>{await onReview(a.id,'rejected'); await load();}}><X size={15}/> Refuser</button></div>}</div>)}</div>;
}
function SetupScreen() {
  return <div className="setup-screen"><div className="setup-card"><span className="brand-mark"><Newspaper size={24}/></span><div className="eyebrow">CONFIGURATION REQUISE</div><h1>Bienvenue sur <em>Prison Times.</em></h1><p>Le site est prêt, mais il faut le connecter à ton projet Supabase pour activer les comptes, les articles et le panel.</p><ol><li>Crée un projet sur <a href="https://supabase.com/" target="_blank" rel="noreferrer">Supabase</a>.</li><li>Dans SQL Editor, exécute le fichier <code>supabase/schema.sql</code> du projet.</li><li>Copie <code>.env.example</code> vers <code>.env</code> et ajoute l'URL du projet et la clé anon.</li><li>Lance <code>npm install</code> puis <code>npm run dev</code>.</li></ol><p className="warning-note">Ne mets jamais une clé <strong>service_role</strong> dans le site. Utilise uniquement la clé anon/public.</p></div></div>;
}

createRoot(document.getElementById('root')).render(<App/>);
